#' Run the SPA for score tests based on the logistic mixed model 
#'
#' @param dosageFile path to dosage file. Each line contains dosages for a marker to be tested
#' @param dosageFileNrowSkip Number of lines to be skiped in the dosage file.
#' @param dosageFileNcolSkip Number of columns to be skiped in the dosage file
#' @param dosageFilecolnamesSkip The column names of the skipped columns 
#' @param bgenFile path to bgen file
#' @param bgenFileIndex path to the .bgi file (index of the bgen file)
#' @param bgenMinMaf minimum minor allele frequency of markers to test (in bgen file)
#' @param bgenMinInfo minimum imputation info of markers to test (in bgen file)
#' @param sampleFile File contains one column for IDs of samples in the dosage or bgen file
#' @param ranges_to_include genome regions to be included from the bgen file
#' @param ranges_to_exclude genome regions to be excluded from the bgen file
#' @param ids_to_include Variant ids to be included from the bgen file
#' @param ids_to_exclude Variant ids to be excluded from the bgen file
#' @param phenoFile path to the phenotype file
#' @param phenoCol column name for the trait e.g. "CAD"
#' @param traitType e.g. "binary" or "quantitative"
#' @param invNormalize perform the inverse normalization of the trait or nor  TRUE or FALSE
#' @param covarColList list of covariates to be used in the glm model e.g c("Sex", "Age")
#' @param qCovarCol list of categorical covariates to be used in the glm model (NOT work yet)
#' @param sampleIDColinphenoFile column name for the sample IDs in the phenotype file e.g. "IID" 
#' @param centerVariables covariates to be centered (around the mean) e.g. c("birthYear")
#' @param GMMATmodelFile path to the input file containing the glmm model, whichi is output from previous step. Will be used by load()
#' @param varianceRatioFile path to the input file containing the variance ratio, which is output from the previous step
#' @param Cutoff bydefault = 2 (SPA test would be used when p value < 0.05 under the normal approximation)
#' @param SPAGMMAToutputFile path to the output file containing the SPAGMMAT test results
#' @return SPAGMMAToutputFile
#' @export
SPAGMMATtest = function(dosageFile = "",
                 dosageFileNrowSkip = 0, 
                 dosageFileNcolSkip = 0,
                 dosageFilecolnamesSkip = c("SNPID CHR POS Allele0 Allele1"),
		 bgenFile = "",
		 bgenFileIndex = "", 
		 sampleFile = "", 
		 ranges_to_include = data.frame(chromosome = NULL, start = NULL, end = NULL),		
		 ranges_to_exclude = data.frame(chromosome = NULL, start = NULL, end = NULL),		
                 ids_to_include = as.character(vector()),	
		 ids_to_exclude = as.character(vector()),
                 minMAF = 0,
        	 bgenMinInfo = 0,
                 phenoFile = "",
		 phenoCol = "",
                 traitType = "binary",
		 invNormalize = FALSE,
		 covarColList = NULL,
                 qCovarCol = NULL,
		 sampleIDColinphenoFile = "", 
                 centerVariables=NULL, 
                 GMMATmodelFile = "", 
                 varianceRatioFile = "", 
                 Cutoff=2, 
                 SPAGMMAToutputFile = "", 
		 IsSparse=TRUE){


	#check and read files
  	#output file
  	if(!file.exists(SPAGMMAToutputFile)){
    		file.create(SPAGMMAToutputFile, showWarnings = TRUE)
  	}

  	#file for the glmm null model
  	if(!file.exists(GMMATmodelFile)){
    		stop("ERROR! GMMATmodelFile ", GMMATmodelFile, " does not exsit\n")
  	}else{
    		load(GMMATmodelFile)
    		glmmNULLModel = modglmm
    		sampleInModel = NULL
    		sampleInModel$IID = glmmNULLModel$sampleID
    		sampleInModel = data.frame(sampleInModel)
    		sampleInModel$IndexInModel = seq(1,length(sampleInModel$IID), by=1)
    		cat(nrow(sampleInModel), " samples have been used to fit the glmm null model\n")
    		#print(sampleInModel$IID[1:10])
  	}

  	if(!file.exists(varianceRatioFile)){
    		stop("ERROR! varianceRatioFile ", varianceRatioFile, " does not exsit\n")
  	}else{
    		varRatio = data.frame(data.table:::fread(varianceRatioFile, header=F, stringsAsFactors=FALSE))[1,1]
    		cat("variance Ratio is ", varRatio, "\n")
  	}


  	#phentoype file
  	if(!file.exists(phenoFile)){
    		stop("ERROR! phenoFile ", phenoFile, " does not exsit\n")
  	}else{
    		ydat = data.table:::fread(phenoFile, header=T, stringsAsFactors=FALSE)
    		data = data.frame(ydat)

    		for (i in c(phenoCol, covarColList, qCovarCol, sampleIDColinphenoFile)){	
      			if (!(i %in% colnames(data))){
        		stop("ERROR! column for ", i, " does not exsit in the phenoFile \n")
      			}
    		}

    		#update the categorical variables
    		qCovarColUpdated = NULL   
    		for(i in qCovarCol){
      			j = paste0("factor(", i, ")")
      			qCovarColUpdated = c(qCovarColUpdated, j)	
    		}
    
    
    		formula = paste0(phenoCol,"~",paste0(c(covarColList,qCovarColUpdated),collapse="+"))
    		formula.null = as.formula(formula)
    		mmat = model.frame(formula.null, data, na.action=NULL)
    		mmat$IID = data[,which(sampleIDColinphenoFile == colnames(data))] 
    		mmat_nomissing = mmat[complete.cases(mmat),]
    		mmat_nomissing$IndexPheno = seq(1,nrow(mmat_nomissing), by=1)
    		cat(nrow(mmat_nomissing), " samples have non-missing phenotypes\n")
    		cat("dim(mmat_nomissing): " ,dim(mmat_nomissing), "\n")
    		#print(mmat_nomissing$IID[1:10])
    		dataMergev0 = merge(mmat_nomissing, sampleInModel, by.x = "IID", by.y = "IID")
    		cat("dim(dataMergev0): " ,dim(dataMergev0), "\n")
    		if(nrow(dataMergev0) < nrow(sampleInModel)){
      			stop("ERROR!", nrow(sampleInModel) - nrow(dataMergev0), " samples used in glmm model fit but do not have non-missing phenotypes\n")
    		}
  	}

  	##Needs to check the number of columns and the number of samples in sample file
  	if(dosageFile != ""){
    		if(!file.exists(dosageFile)){
      			stop("ERROR! dosageFile ", dosageFile, " does not exsit\n")
    		}else{
      			if(dosageFileNrowSkip < 0 | dosageFileNcolSkip < 0){
        			stop("ERROR! dosageFileNrowSkip or dosageFileNcolSkip can't be less than zero\n")
      			}
    		}
    		dosageFileType = "plain"

  	}else if(bgenFile != ""){ 
    		if(!file.exists(bgenFile)){
      			stop("ERROR! bgenFile ", bgenFile, " does not exsit\n")
    		}
		#bgenFileIndex is not necessary if there is no query
    		#if(!file.exists(bgenFileIndex)){
      		#	stop("ERROR! bgenFileIndex ", bgenFileIndex, " does not exsit\n")
    		#}
   		dosageFileType = "bgen"
  	}

  	#sample file
  	if(!file.exists(sampleFile)){
    		stop("ERROR! sampleFile ", sampleFile, " does not exsit\n")
  	}else{
    		#sampleListinDosage = data.frame(data.table:::fread(sampleFile, header=F, stringsAsFactors=FALSE))
    		sampleListinDosage = data.frame(data.table:::fread(sampleFile, header=T, stringsAsFactors=FALSE))
    		sampleListinDosage$IndexDose = seq(1,nrow(sampleListinDosage), by=1)
    		colnames(sampleListinDosage)[1] = "IIDDose"
    		dataMerge = merge(dataMergev0, sampleListinDosage, by.x="IID", by.y = "IIDDose")
    		dataMerge_sort = dataMerge[with(dataMerge, order(IndexInModel)), ]
   

    		if(nrow(dataMerge_sort) < nrow(sampleInModel)){
      		stop("ERROR!", nrow(sampleInModel) - nrow(dataMerge_sort), " samples used in glmm model fit do not have dosages\n")
    		}else{
      			#0909 modified by WZ
      			dataMerge_v2 = merge(dataMergev0, sampleListinDosage, by.x="IID", by.y = "IIDDose", all.y = TRUE)
      			dataMerge_v2_sort = dataMerge_v2[with(dataMerge_v2, order(IndexDose)), ]	
      			sampleIndex = dataMerge_v2_sort$IndexInModel
      			sampleIndex[is.na(sampleIndex)] = -10  ##with a negative number 
    		}
  	}

  	#center some covariates
  	if(length(centerVariables)!=0){
    		for(i in centerVariables){
      			if (!(i %in% colnames(dataMerge_sort))){
        			stop("ERROR! column for ", i, " does not exsit in the phenoFile \n")
      			}else{
        			dataMerge_sort[,which(colnames(dataMerge_sort) == i)] = dataMerge_sort[,which(colnames(dataMerge_sort) == i)] - mean(dataMerge_sort[,which(colnames(dataMerge_sort) == i)])
      			}
    		}
  	}

  	startTime = as.numeric(Sys.time())  # start time of the SPAGMMAT tests
  	cat("Analysis started at ", startTime, "Seconds\n")

  	if(traitType == "binary"){
    		cat(phenoCol, " is a binary trait\n")
    		uniqPheno = sort(unique(dataMerge_sort[,which(colnames(dataMerge_sort) == phenoCol)]))
    		if (uniqPheno[1] != 0 | uniqPheno[2] != 1){
      			stop("ERROR! phenotype value needs to be 0 or 1 \n")
    		}

    		fit0 = glm(formula.null,data=dataMerge_sort, family=binomial)
    		obj.noK = SPAtest:::ScoreTest_wSaddleApprox_NULL_Model(formula.null, data = dataMerge_sort)

    		if (dosageFileType == "plain"){
      			scoreTest_SPAGMMAT_binaryTrait_plainDosage(testGenoFile = dosageFile, testGenofileNrowSkip = dosageFileNrowSkip, testGenofileNcolSkip = dosageFileNcolSkip, minMAF = minMAF, obj.glmm.null = glmmNULLModel, obj.glm.null = fit0, obj.noK = obj.noK, varRatio = varRatio, testOut = SPAGMMAToutputFile, sampleIndex = sampleIndex, dosageFilecolnamesSkip=dosageFilecolnamesSkip, Cutoff = 2, IsSparse=IsSparse)

    		}else if (dosageFileType == "bgen"){

      			scoreTest_SPAGMMAT_binaryTrait_bgenDosage(testbgenFile = bgenFile,testbgenFileIndex = bgenFileIndex, obj.glmm.null = glmmNULLModel, obj.glm.null = fit0, obj.noK = obj.noK, varRatio = varRatio, testOut = SPAGMMAToutputFile, sampleIndex = sampleIndex, Cutoff = 2, ranges_to_exclude = ranges_to_exclude, ranges_to_include = ranges_to_include, ids_to_exclude= ids_to_exclude, ids_to_include= ids_to_include,  bgenMinMaf = minMAF, bgenMinInfo = bgenMinInfo, IsSparse=IsSparse)
    		}


  	}else if(traitType == "quantitative"){
    		cat(phenoCol, " is a quantitative trait\n")

    		if(invNormalize){
      			cat("Perform the inverse nomalization for ", phenoCol, "\n")
      			invPheno = qnorm((rank(dataMerge_sort[,which(colnames(dataMerge_sort) == phenoCol)], na.last="keep")-0.5)/sum(!is.na(dataMerge_sort[,which(colnames(dataMerge_sort) == phenoCol)])))
      			dataMerge_sort[,which(colnames(dataMerge_sort) == phenoCol)] = invPheno
    		}

    		obj.noK = ScoreTest_wSaddleApprox_NULL_Model_q(formula.null, dataMerge_sort)
    		fit0 = glm(formula.null, data=dataMerge_sort,family=gaussian(link = "identity"))

    		if (dosageFileType == "plain"){

      			scoreTest_SPAGMMAT_quantitativeTrait_plainDosage(testGenoFile = dosageFile, testGenofileNrowSkip = dosageFileNrowSkip, testGenofileNcolSkip = dosageFileNcolSkip, obj.glmm.null = glmmNULLModel, obj.glm.null = fit0, obj.noK = obj.noK, varRatio = varRatio, testOut = SPAGMMAToutputFile, sampleIndex = sampleIndex, dosageFilecolnamesSkip=dosageFilecolnamesSkip, Cutoff = 2)

    		}else if (dosageFileType == "bgen"){

      			scoreTest_SPAGMMAT_quantitativeTrait_bgenDosage(testbgenFile = bgenFile,testbgenFileIndex = bgenFileIndex, obj.glmm.null = glmmNULLModel, obj.glm.null = fit0, obj.noK = obj.noK, varRatio = varRatio, testOut = SPAGMMAToutputFile, sampleIndex = sampleIndex, Cutoff = 2, ranges_to_exclude = ranges_to_exclude, ranges_to_include = ranges_to_include, ids_to_exclude= ids_to_exclude, ids_to_include= ids_to_include, bgenMinMaf = bgenMinMaf, bgenMinInfo = bgenMinInfo)
    		}

  	}else{
    		stop("ERROR! The type of the trait has to be either binary or quantitative\n")
  	}

  	endTime = as.numeric(Sys.time()) #end time of the SPAGMMAT tests
  	cat("Analysis ended at ", endTime, "Seconds\n")
  	tookTime = endTime - startTime
  	cat("Analysis took ", tookTime, "Seconds\n")
  
}


scoreTest_SPAGMMAT_binaryTrait=function(g, NAset, y, mu, varRatio, Cutoff){
	q = innerProduct(g, y)  
  	m1 = innerProduct(g, mu) 
  	var2 = innerProduct(mu*(1-mu), g*g)
  	var1 = var2 * varRatio
  	qtilde = (q-m1)/sqrt(var1) * sqrt(var2) + m1

  	if(length(NAset)/length(g) < 0.5){
    		out1 = SPAtest:::Saddle_Prob(q=qtilde, mu = mu, g = g, Cutoff = Cutoff, alpha=5*10^-8)
  	}else {
    		out1 = SPAtest:::Saddle_Prob_fast(q=qtilde,g = g, mu = mu, gNA = g[NAset], gNB = g[-NAset], muNA = mu[NAset], muNB = mu[-NAset], Cutoff = Cutoff, alpha = 5*10^-8)
  	}

  	out1 = c(out1, var1 = var1)
  	out1 = c(out1, var2 = var2)
  	return(out1)
}

scoreTest_SPAGMMAT_quantitativeTrait=function(G0, obj.noK, AC, y, mu, varRatio, tauVec){
#scoreTest_SPAGMMAT_quantitativeTrait=function(G0, XXVX_invXV, AC, y, mu, varRatio, tauVec){
#  G = G0  -  obj.noK$XXVX_inv %*%  (obj.noK$XV %*% G0) # G1 is X adjusted 
#  G = G0  -  XXVX_invXV %*% G0 # G1 is X adjusted 
	XVG0 = eigenMapMatMult(obj.noK$XV, G0)
   	G = G0  -  eigenMapMatMult(obj.noK$XXVX_inv, XVG0) # G1 is X adjusted 

  	g = G/sqrt(AC)
  	var2 = innerProduct(g, g)
  	q = innerProduct(g, y)
  	m1 = innerProduct(mu, g)

  	var1 = var2 * varRatio
  	Tv1 = (q-m1)/tauVec[1]
  	p.value = pchisq(Tv1^2/var1, lower.tail = FALSE, df=1)
  	out1 = list(p.value = p.value, var1 = var1, var2 = var2)
  	return(out1)
}


scoreTest_SPAGMMAT_binaryTrait_plainDosage = function(testGenoFile, testGenofileNrowSkip, testGenofileNcolSkip, minMAF, obj.glmm.null,obj.glm.null, obj.noK, varRatio, testOut, sampleIndex, dosageFilecolnamesSkip, Cutoff = 2,  IsSparse){
	if(file.exists(testOut)){file.remove(testOut)}
  		resultHeader = c(dosageFilecolnamesSkip, "p.value", "p.value.NA", "Is.converge","var1","var2", "N", "NCase", "NCtrl", "AC", "AC.Case", "AC.Ctrl", "AF", "AF.Case", "AF.Ctrl")
   	#resultHeader = c(dosageFilecolnamesSkip,"AC","AF" "N", "p.value", "p.value.NA", "Is.converge","var1","var2")
  		write(resultHeader,file = testOut, ncolumns = length(resultHeader))
  		if(Cutoff < 10^-2){
    			Cutoff=10^-2
  		}
 		mu = obj.glmm.null$fitted.values
  		y = obj.glm.null$y
  		if(minMAF < 0.5/length(mu)){minMAF = 5/length(mu)}  #filter out monomorphic markers
  			Mtest = setgenoTest_plainDosage(testGenoFile, testGenofileNrowSkip, testGenofileNcolSkip)
  			OUT = NULL
  			numPassMarker = 0
			y1Index = which(y == 1)
			NCase = length(y1Index)
			y0Index = which(y == 0)
        		NCtrl = length(y0Index)
        		sampleIndex = sampleIndex - 1

        		##########################
        		# Added by SLEE 09/06/2017
        		mu.a<-as.vector(mu)
        		mu2.a<-mu.a *(1-mu.a)
        		obj.noK$XVX = t(obj.noK$X1) %*% (obj.noK$X1 * mu2.a)
        		obj.noK$XVX_inv_XV = obj.noK$XXVX_inv * obj.noK$V
        		obj.noK$S_a = colSums(obj.noK$X1 * (y - mu.a))


        		# Added by SLEE 09/07/2017
        		N = length(y)
        		SetSampleIdx_plainDosage(sampleIndex, N);


			###########################
  			startTime = as.numeric(Sys.time()) #start time of the SPAGMMAT tests
  			NSparse=0
  			for(mth in 1:Mtest){
    				proc.time()
    				G0 = getGenoOfnthVar_plainDosage(mth, testGenofileNrowSkip, testGenofileNcolSkip)
				#cat("length(G0) ", length(G0), "\n")
    				AC.Case = sum(G0[y1Index])
    				AC.Ctrl = sum(G0[y0Index])
    				AF.Case = AC.Case/(2*NCase)
    				AF.Ctrl = AC.Ctrl/(2*NCtrl)
    				AC = sum(G0)
    				N = length(G0)
    				AF = AC/(2*N)
				MAF = min(AF, 1-AF)
				#cat("AF ", AF, "\n")
				#cat("AF.Case ", AF.Case, "\n")
				#cat("AF.Ctrl ", AF.Ctrl, "\n")
    				if(MAF >= minMAF){
					numPassMarker = numPassMarker + 1
    					rowHeader=getrowHeaderVec_plainDosage()
					if(AF > 0.5){
                               		 	G0 = 2-G0
                                		AC2 = 2*N - AC
                        		}else{
                               			AC2 = AC
                        		}  
					##########################
                        		## Added by SLEE 09/06/2017
                        		Run1=TRUE
                        		if(IsSparse==TRUE){
                                		if(MAF < 0.05){
                                        		out.score<-Score_Test_Sparse(obj.noK, G0,mu.a, mu2.a, varRatio );
                                 		}else{
                                        		out.score<-Score_Test(obj.noK, G0,mu.a, mu2.a, varRatio );
                                		}
                                		if(out.score[1] > 0.05){

                                        		OUT = rbind(OUT, c(rowHeader, out.score, N, NCase, NCtrl, AC, AC.Case, AC.Ctrl,AF, AF.Case, AF.Ctrl))
	                                       		NSparse=NSparse+1
                                        		Run1=FALSE
                                		}
                        		}
					if(Run1){

                                		G0 = matrix(G0, ncol = 1)
                                		XVG0 = eigenMapMatMult(obj.noK$XV, G0)
                                		G = G0  -  eigenMapMatMult(obj.noK$XXVX_inv, XVG0) # G1 is X adjusted
                                		g = G/sqrt(AC2)
                                		NAset = which(G0==0)
                                		out1 = scoreTest_SPAGMMAT_binaryTrait(g, NAset, y, mu, varRatio, Cutoff = Cutoff)
                                		out1 = unlist(out1)
						OUT = rbind(OUT, c(rowHeader, out1["p.value"], out1["p.value.NA"], out1["Is.converge"], out1["var1"], out1["var2"], N, NCase, NCtrl, AC, AC.Case, AC.Ctrl,AF, AF.Case, AF.Ctrl))
                        }
		}


    		if(mth %% 1000 == 0 | mth == Mtest){
			ptm <- proc.time()
                        print(ptm)     
 			print(mth)
			cat("numPassMarker: ", numPassMarker, "\n")
      			OUT = as.data.frame(OUT)
      			write.table(OUT, testOut, quote=FALSE, row.names=FALSE, col.names=FALSE, append = TRUE)
      			OUT = NULL
    		}    
  	} #end of the for(mth in 1:Mtest) loop

  	closetestGenoFile_plainDosage()
  	return(OUT)
}




scoreTest_SPAGMMAT_quantitativeTrait_plainDosage = function(testGenoFile, testGenofileNrowSkip, testGenofileNcolSkip, obj.glmm.null,obj.glm.null, obj.noK, varRatio, testOut, sampleIndex, dosageFilecolnamesSkip, Cutoff = 2){
#  cat("DEBUG0\n")

  if(file.exists(testOut)){file.remove(testOut)}
  resultHeader = c(dosageFilecolnamesSkip, "p.value", "p.value.NA", "Is.converge","var1","var2","N","AC", "AF")
  write(resultHeader,file = testOut, ncolumns = length(resultHeader))
  if(Cutoff < 10^-2){
    Cutoff=10^-2
  }
 
 
#  cat("DEBUG1\n")
  tauVec = obj.glmm.null$theta
  mu = obj.glmm.null$fitted.values
  y = obj.glm.null$y
  Mtest = setgenoTest_plainDosage(testGenoFile, testGenofileNrowSkip, testGenofileNcolSkip)
#  cat("DEBUG2\n")
  OUT = NULL
  for(mth in 1:Mtest){
    proc.time()

    G0a = getGenoOfnthVar_plainDosage(mth, testGenofileNrowSkip, testGenofileNcolSkip)
    G0b = G0a[sampleIndex]
    #G0 = G0b[which(G0b != -1)] #remove samples with missing dosages
    #y = y[which(G0b != -1)] # remove sample with missing dosages
    #mu = mu[which(G0b != -1)] # remove samples with missing dosages


    AC = sum(G0)
    N = length(G0)
    AF = AC/(2*N)
    rowHeader=getrowHeaderVec_plainDosage()
    if(AF != 0 & AF != 1){
      out1 = scoreTest_SPAGMMAT_quantitativeTrait(G0, obj.noK, AC, y, mu, varRatio, tauVec)
      OUT = rbind(OUT, c(rowHeader, out1$p.value, out1$var1, out1$var2, N, AC, AF))
    }else{
      OUT = rbind(OUT, c(rowHeader, NA, NA, NA, N, AC, AF))
    }

    if(mth %% 1000 == 0 | mth == Mtest){
      print(mth)
      OUT = as.data.frame(OUT)
      write.table(OUT, testOut, quote=FALSE, row.names=FALSE, col.names=FALSE, append = TRUE)
      OUT = NULL
    }
  }

  closetestGenoFile_plainDosage()
  return(OUT)
}




scoreTest_SPAGMMAT_binaryTrait_bgenDosage = function(testbgenFile,testbgenFileIndex,obj.glmm.null,obj.glm.null, obj.noK, varRatio, testOut, sampleIndex, dosageFilecolnamesSkip = c("CHR","POS","SNPID","Allele1","Allele2", "AC", "AF"), Cutoff = 2, ranges_to_exclude, ranges_to_include, ids_to_exclude, ids_to_include, bgenMinMaf, bgenMinInfo, IsSparse){
	if(file.exists(testOut)){file.remove(testOut)}
  	#resultHeader = c(dosageFilecolnamesSkip, "p.value", "p.value.NA", "Is.converge","var1","var2", "N", "NCase", "NCtrl", "AC", "AC.Case", "AC.Ctrl", "AF", "AF.Case", "AF.Ctrl")
 	resultHeader = c(dosageFilecolnamesSkip, "N", "p.value", "p.value.NA", "Is.converge","var1","var2")
  	write(resultHeader,file = testOut, ncolumns = length(resultHeader))
  	if(Cutoff < 10^-2){
    		Cutoff=10^-2
  	}
  	mu = obj.glmm.null$fitted.values
	y = obj.glm.null$y
	if(bgenMinMaf < 0.5/length(mu)){bgenMinMaf = 0.5/length(mu)} #filter out monomorphic markers 

	NCase = sum(y == 1)
  	NCtrl = sum(y == 0)
  	Mtest = setgenoTest_bgenDosage(testbgenFile,testbgenFileIndex, ranges_to_exclude = ranges_to_exclude, ranges_to_include = ranges_to_include, ids_to_exclude= ids_to_exclude, ids_to_include= ids_to_include)
  	#Mtest = 10000
  	isQuery = getQueryStatus()
  	OUT = NULL
  	numPassMarker = 0
  	sampleIndex = sampleIndex - 1
  
 	##########################
  	# Added by SLEE 09/06/2017
  	mu.a<-as.vector(mu)
  	mu2.a<-mu.a *(1-mu.a)
  	obj.noK$XVX = t(obj.noK$X1) %*% (obj.noK$X1 * mu2.a)
  	obj.noK$XVX_inv_XV = obj.noK$XXVX_inv * obj.noK$V
  	obj.noK$S_a = colSums(obj.noK$X1 * (y - mu.a))

  	###########################

	############################
  	# Added by SLEE 09/07/2017
  	N = length(y)
  	SetSampleIdx(sampleIndex, N);
  	##

#
  	startTime = as.numeric(Sys.time()) #end time of the SPAGMMAT tests
  	NSparse=0

  	for(mth in 1:Mtest){
    		if(isQuery){
      			Gx = getDosage_bgen_withquery()
    		}else{
      			Gx = getDosage_bgen_noquery()
    		}

    		markerInfo = getMarkerInfo()
    		#G0a = Gx$dosages
    		#G0 = reOrderByIndices(G0a, sampleIndex) 
    		#AC = sum(G0)
    		#N = length(G0)
    		#AF = AC/(2*N)
		G0 = Gx$dosages
    		AC = Gx$variants$AC
    		AF = Gx$variants$AF
    		MAF = min(AF, 1-AF)
		

    		if(MAF >= bgenMinMaf & markerInfo >= bgenMinInfo){ 
      			numPassMarker = numPassMarker + 1 
      			rowHeader=as.vector(unlist(Gx$variants))

      			if(AF > 0.5){
        			G0 = 2-G0
        			AC2 = 2*N - AC
      			}else{
        			AC2 = AC
      			}

     			##########################
      			## Added by SLEE 09/06/2017
      			Run1=TRUE
      			if(IsSparse==TRUE){
        			if(MAF < 0.05){
          				out.score<-Score_Test_Sparse(obj.noK, G0,mu.a, mu2.a, varRatio );
        			 }else{
          				out.score<-Score_Test(obj.noK, G0,mu.a, mu2.a, varRatio );
         			}
         			if(out.score[1] > 0.05){

           				OUT = rbind(OUT, c(rowHeader, N, out.score))
           				NSparse=NSparse+1
           				Run1=FALSE
				}
			}  
       			if(Run1){

         			G0 = matrix(G0, ncol = 1)
         			XVG0 = eigenMapMatMult(obj.noK$XV, G0)
         			G = G0  -  eigenMapMatMult(obj.noK$XXVX_inv, XVG0) # G1 is X adjusted
         			g = G/sqrt(AC2)
         			NAset = which(G0==0)
         			out1 = scoreTest_SPAGMMAT_binaryTrait(g, NAset, y, mu, varRatio, Cutoff = Cutoff)
         			out1 = unlist(out1)
         			OUT = rbind(OUT, c(rowHeader, N, out1["p.value"], out1["p.value.NA"], out1["Is.converge"], out1["var1"], out1["var2"]))
     			}

   		} #end of the if(MAF >= bgenMinMaf & markerInfo >= bgenMinInfo)

		if(mth %% 100000 == 0 | mth == Mtest){
			ptm <- proc.time()
			print(ptm)
			print(mth)	
      			cat("numPassMarker: ", numPassMarker, "\n")
      			OUT = as.data.frame(OUT)	
      			write.table(OUT, testOut, quote=FALSE, row.names=FALSE, col.names=FALSE, append = TRUE)
      			OUT = NULL
    		}
  	} #end of the for(mth in 1:Mtest) loop

#  closetestGenoFile()
  return(OUT)
}




scoreTest_SPAGMMAT_quantitativeTrait_bgenDosage = function(testbgenFile,testbgenFileIndex, obj.glmm.null,obj.glm.null, obj.noK, varRatio, testOut, sampleIndex, dosageFilecolnamesSkip = c("CHR","POS","SNPID","Allele1","Allele2"), Cutoff = 2, ranges_to_exclude, ranges_to_include, ids_to_exclude, ids_to_include, bgenMinMaf, bgenMinInfo){
  if(file.exists(testOut)){file.remove(testOut)}
  resultHeader = c(dosageFilecolnamesSkip, "p.value", "p.value.NA", "Is.converge","var1","var2","N","AC", "AF")
  write(resultHeader,file = testOut, ncolumns = length(resultHeader))
  if(Cutoff < 10^-2){
    Cutoff=10^-2
  }

  tauVec = obj.glmm.null$theta
  mu = obj.glmm.null$fitted.values
  y = obj.glm.null$y
  Mtest = setgenoTest_bgenDosage(testbgenFile,testbgenFileIndex, ranges_to_exclude = ranges_to_exclude, ranges_to_include = ranges_to_include, ids_to_exclude= ids_to_exclude, ids_to_include= ids_to_include)

  isQuery = getQueryStatus()

  OUT = NULL
  numPassMarker = 0
  for(mth in 1:Mtest){
    proc.time()

    if(isQuery){
      Gx = getDosage_bgen_withquery()
    }else{
      Gx = getDosage_bgen_noquery()
    }


    markerInfo = getMarkerInfo()
#    cat("markerInfo: ",  markerInfo, "\n")

    G0a = Gx$dosages
    G0 = G0a[sampleIndex]
    AC = sum(G0)
    N = length(G0)
    AF = AC/(2*N)
    MAF = min(AF, 1-AF)

    if(MAF >= bgenMinMaf & markerInfo >= bgenMinInfo){
      #Gx = getGenoOfnthVar_bgenDosage(mth)
      rowHeader=as.vector(unlist(Gx$variants))
      numPassMarker = numPassMarker + 1
    #G0a = Gx$dosages
    #G0 = G0a[sampleIndex]
    #G0b = G0a[sampleIndex]
    #G0 = G0b[which(G0b != -1)] #remove samples with missing dosages
    #y = y[which(G0b != -1)] # remove sample with missing dosages
    #mu = mu[which(G0b != -1)] # remove samples with missing dosages


    #AC = sum(G0)
    #N = length(G0)
    #AF = AC/(2*N)
    #rowHeader=getrowHeaderVec()
    if(AF != 0 & AF != 1){
      ptm <- proc.time()
      print(ptm)
      print("before test")	
      out1 = scoreTest_SPAGMMAT_quantitativeTrait(G0, AF, AC, N, obj.noK, AC, y, mu, varRatio, tauVec)
      ptm <- proc.time()
      print(ptm)
      print("after test")	
	
      OUT = rbind(OUT, c(rowHeader, out1["p.value"], out["var1"], out1["var2"], N, AC, AF))

    }else{
      OUT = rbind(OUT, c(rowHeader, NA, NA, NA, N, AC, AF))
    }

   }

    if(mth %% 1000 == 0 | mth == Mtest){
      ptm <- proc.time()
      print(ptm)
      print(mth)
      cat("numPassMarker: ", numPassMarker, "\n")
      OUT = as.data.frame(OUT)
      write.table(OUT, testOut, quote=FALSE, row.names=FALSE, col.names=FALSE, append = TRUE)
      OUT = NULL
    }
  }

  #closetestGenoFile()
  return(OUT)

}


########################
#	Added by SLEE 09/06/2017
#

Score_Test_Sparse<-function(obj.null, G, mu, mu2, varRatio ){
	
	# mu=mu.a; mu2= mu2.a; G=G0; obj.null=obj.noK
	idx_no0<-which(G>0)

	g1<-G[idx_no0]
	A1<-obj.null$XVX_inv_XV[idx_no0,]
	X1<-obj.null$X1[idx_no0,]
	mu21<-mu2[idx_no0]
	mu1<-mu[idx_no0]
	y1<-obj.null$y[idx_no0]


	Z = t(A1) %*% g1
	#Z = eigenMapMatMult(t(A1), g1)
	B<-X1 %*% Z
	g_tilde1 = g1 - B
	var2 = t(Z) %*% obj.null$XVX %*% Z - t(B^2) %*% mu21 + t(g_tilde1^2) %*% mu21
	var1 = var2 * varRatio
	
	S1 = crossprod(y1-mu1, g_tilde1)
	S_a2 = obj.null$S_a - colSums(X1 * (y1 - mu1))
	S2 = -S_a2 %*% Z
	S<- S1+S2
	
	pval.noadj<-pchisq((S)^2/(var1), lower.tail = FALSE, df=1)
	return(c(pval.noadj, pval.noadj, TRUE, var1, var2))
	
}

Score_Test<-function(obj.null, G, mu, mu2, varRatio){

	g<-G  -  obj.null$XXVX_inv %*%  (obj.null$XV %*% G)
	q<-crossprod(g, obj.null$y) 
	m1<-crossprod(mu, g)
	var2<-crossprod(mu2, g^2)
	var1 = var2 * varRatio
	S = q-m1

	pval.noadj<-pchisq((S)^2/var1, lower.tail = FALSE, df=1)
	return(c(pval.noadj, pval.noadj, TRUE, var1, var2))
}
